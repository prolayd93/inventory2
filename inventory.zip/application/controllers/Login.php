<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{  
		parent:: __construct();
		$this->load->model('logins_model');
	}
		
	public function index()
	{
		//print_r($this->session);
		if(!empty($this->session->userdata("client_id"))){redirect('Admin/index'); } 
		$data['title'] = 'Inventory | login';
		$data['page'] = "Login";
		$this->load->view('template/login_header',$data);		
		$this->load->view('login',$data);
		$this->load->view('template/login_footer');
		
	}

	public function admin_login(){

		$status=$this->logins_model->admin_login();
		$data['client_id']=$this->session->userdata('client_id');		
		if($status=='success'){
				redirect('Admin/index'); 
			}
		 else
			{
				$data['error']='error';
				$this->load->view('template/login_header');
				$this->load->view('login',$data);
				$this->load->view('template/login_footer');
			}
	}

	function checkSession()
	{
		  if($this->session->userdata("client_id")=='')
		  {
			  echo 0;
		  }
	}
	  
		
 function logout() 
	{
        $this->session->sess_destroy();
        redirect('home');
	}
}
