<?php   if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends CI_Controller  
{  
	//private $pageTitle;
	function __construct(){  
		parent:: __construct();		
		$this->load->model('Client_model');		
		$this->load->library('image_lib');
		$this->load->library('session');
	}
	
	 public function index($id=false){
	 	if($this->session->userdata("client_id")==''){redirect('login/index'); }  
		    $data['error']='';
		    $data['page']='Dashboard';
		    $data['title'] ='Inventory | Dashboard';
		    $this->load->view('template/header', $data);		    
			$this->load->view('admin_dashboard',$data);
			$this->load->view('template/footer'); 
			 
	}
	public function manufacture(){
		if($this->session->userdata("client_id")==''){redirect('login/index'); }  
		    $data['error']='';
		    $data['page']='Manufacture';
			$data['mrecord']=$this->Client_model->get_record_manufacture();
		    $data['title'] ='Inventory | Manufacture';
		    $this->load->view('template/header', $data);		    
			$this->load->view('manufacture',$data);
			$this->load->view('template/footer'); 
	}
	public function model(){
		if($this->session->userdata("client_id")==''){redirect('login/index'); }  
		    $data['error']='';
		    $data['page']='Model';
		    $data['title'] ='Inventory | Model';
			$data['model_query']=$this->Client_model->get_manufacture_data('model_tbl','select','status','1');			
		    $this->load->view('template/header', $data);		    
			$this->load->view('model',$data);
			$this->load->view('template/footer'); 
	}

	public function inventory(){
		if($this->session->userdata("client_id")==''){redirect('login/index'); }  
		    $data['error']='';
		    $data['page']='Inventory';
		    $data['title'] ='Inventory | Inventory';
		    $this->load->view('template/header', $data);		    
			$this->load->view('inventory',$data);
			$this->load->view('template/footer'); 
	}

	public function add_manufacture(){
		if($this->session->userdata("client_id")==''){redirect('login/index'); } 			
		    $data['error']='';
		    $data['page']='Add Manufacture';
		    $data['title'] ='Inventory | Add Manufacture';
			if($this->input->post('save')){				
			$status=$this->Client_model->add_manufacture_record();
			
			if($status=='success'){
				redirect('Admin/manufacture'); 
			}
			}
		    $this->load->view('template/header', $data);		    
			$this->load->view('add_manufacture',$data);
			$this->load->view('template/footer'); 
	}
	public function add_model(){
		if($this->session->userdata("client_id")==''){redirect('login/index'); } 
			$data['manufacture_data']=$this->Client_model->get_manufacture_data('manufacture','select','status','1');
			if($this->input->post('save')){	
			$status=$this->Client_model->add_model_record();
				if($status=='success'){
				redirect('Admin/model'); 
			}
			}
		    $data['error']='';
		    $data['page']='Add Model';
		    $data['title'] ='Inventory | Add Model';
		    $this->load->view('template/header', $data);		    
			$this->load->view('add_model',$data);
			$this->load->view('template/footer'); 
	}
	
	
	//adding new items
	public function upload_files(){		
		$a=$this->Client_model->upload_files();
		print_r($a);
		
	}	

	
}