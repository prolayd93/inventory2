<header class="page-header">
	<h2><?php echo $page;?></h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="<?php echo  base_url(); ?>index.php/Admin/index">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span><?php echo $page;?></span></li>
		</ol>

		<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
			<a href="#" class="fa fa-times"></a>
		</div>

		<h2 class="panel-title"><?php echo $page;?></h2>
	</header>
	<div class="panel-body">
	<div class="row">
		<div class="col-sm-6">
			<div class="mb-md">
				<a href="<?php echo  base_url(); ?>index.php/admin/add_manufacture" class="btn btn-primary">Add <i class="fa fa-plus"></i></a>
			</div>
		</div>
	</div>

		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th>Manufacture Name</th>
					<th>Created</th>
					<th>Actions</th>
					
				</tr>
			</thead>
			<tbody>
			<?php 
			//echo "<pre>", print_r($mrecord), "</pre>";
			if(!empty($mrecord)){
			foreach($mrecord as $mrc) {?>			
				<tr class="gradeX">
					<td><?php echo $mrc['attr_name'];?></td>
					<td><?php echo $mrc['created'];?>
					</td>
					<td>
						<a href="<?php echo base_url();?>index.php/admin/edit_manufacture/<?php echo $mrc['client_id'];?>" class="on-default edit-row"><i class="fa fa-pencil"></i></a>
						<a href="javascript:void;" class="on-default remove-row"><i class="fa fa-trash-o" onClick="delete_product(<?php echo $mrc['id'];?>)"></i></a>
					</td>
					
				</tr>
			<?php }
			}
			?>
				
			</tbody>
		</table>
	</div>
</section>
