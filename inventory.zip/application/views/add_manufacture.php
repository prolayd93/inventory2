
<header class="page-header">
	<h2><?php echo $page;?></h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="<?php echo  base_url(); ?>index.php/Admin/index">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span><a href="<?php echo  base_url(); ?>index.php/admin/manufacture">Manufacture</a></span></li>
			<li><span><?php echo $page;?></span></li>
		</ol>

		<a class="sidebar-right-toggle" data-open=""><i class="fa fa-chevron-left"></i></a>
	</div>
</header>

<!-- start: page -->
<div class="row">
<div class="col-md-12">
	<form id="form" action="<?php echo base_url();?>index.php/admin/add_manufacture" method="post" class="form-horizontal">
		<section class="panel">
			<header class="panel-heading">
				<div class="panel-actions">
					<a href="#" class="fa fa-caret-down"></a>
					<a href="#" class="fa fa-times"></a>
				</div>
				<h2 class="panel-title">Manufacture Form</h2>				
			</header>
			<div class="panel-body">
				<div class="form-group">
					<label class="col-sm-3 control-label">Manufacture Name <span class="required">*</span></label>
					<div class="col-sm-9">
						<input type="text" name="manufacture_name" id="m_name" class="form-control" placeholder="" required/>
					</div>
				</div>
			</div>
			<footer class="panel-footer">
				<div class="row">
					<div class="col-sm-9 col-sm-offset-3">
						<input type="hidden" name="save" value="save"/>
						<button class="btn btn-primary">Submit</button>
						<button type="reset" class="btn btn-default">Reset</button>
					</div>
				</div>
			</footer>
		</section>
	</form>
</div>
</div>


		
