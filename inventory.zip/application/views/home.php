<!DOCTYPE html>
<html>
	<head>

		<!-- Basic -->
		<meta charset="utf-8">
		<title>Shop | Porto - Responsive HTML5 Template 3.7.0</title>		
		<meta name="keywords" content="HTML5 Template" />
		<meta name="description" content="Porto - Responsive HTML5 Template">
		<meta name="author" content="okler.net">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800%7CShadows+Into+Light" rel="stylesheet" type="text/css">

<script src='<?php echo base_url();?>assets/angular/angular.min.js'></script>


		<!-- Vendor CSS -->
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/vendor/bootstrap/bootstrap.css">
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/vendor/fontawesome/css/font-awesome.css">
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/vendor/owlcarousel/owl.carousel.min.css" media="screen">
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/vendor/owlcarousel/owl.theme.default.min.css" media="screen">
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/vendor/magnific-popup/magnific-popup.css" media="screen">

		<!-- Theme CSS -->
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/css/theme.css">
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/css/theme-elements.css">
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/css/theme-blog.css">
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/css/theme-shop.css">
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/css/theme-animate.css">

		<!-- Skin CSS -->
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/css/skins/default.css">

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="<?php echo  base_url(); ?>assets/front/css/custom.css">
		

		<!-- Head Libs -->
		<script src="<?php echo  base_url(); ?>assets/front/vendor/modernizr/modernizr.js"></script>

	</head>
<body ng-app='myapp'>

		<div class="body">
			<header id="header">
				<div class="container">
					<div class="logo">
						<a href="index.html">
							<img alt="Porto" width="111" height="54" data-sticky-width="82" data-sticky-height="40" src="<?php echo  base_url(); ?>assets/front/img/logo.png">
						</a>
					</div>
					<div class="search">
						
					</div>
					
				
					<button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse">
						<i class="fa fa-bars"></i>
					</button>
				</div>
				<div class="navbar-collapse nav-main-collapse collapse">
					<div class="container">
						<nav class="nav-main mega-menu">
							<ul class="nav nav-pills nav-main" id="mainMenu">
								
								<li>
									<a href="<?php echo  base_url(); ?>index.php/login">Backend</a>
								</li>
								
									
								
								
							</ul>
						</nav>
					</div>
				</div>
			</header>

			<div role="main" class="main shop">

				<div class="container">

					<hr class="tall">

					<div class="row">
						<div class="col-md-6">
							<h1 class="shorter"><strong>Car Inventory</strong></h1>
							
						</div>
					</div>

					<div class="row" ng-controller='inventoryCtrl'>
					
						<table cellspacing="0" class="cart">
						<thead>
						<th>Serial Number</th>
						<th>Manufacturer Name</th>
						<th>Model Name</th>
						<th>Count</th>
						</thead>
							<tbody>
								<tr  ng-repeat='inven in invens' ng-click="invdetails(inven)">
									 <td>{{ inven.id }}</td>
									 <td>{{ inven.attr_name }}</td>
									 <td>{{ inven.model_name }}</td>
									 <td>{{ inven.username }}</td>									 
								</tr>
								
							</tbody>
						</table>
					</div>

					</div>					
				</div>

			</div>

			<footer id="footer">
				
				<div class="footer-copyright">
					<div class="container">
						<div class="row">
							<div class="col-md-1">
								<a href="#" class="logo">
									Inventory
								</a>
							</div>
							<div class="col-md-7">
								<p>© Copyright <?php echo date('Y');?>. All Rights Reserved.</p>
							</div>
							<div class="col-md-4">
								
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>
		
		
		<div id="modalHeaderColorPrimary" class="modal-block modal-header-color modal-block-primary mfp-hide">
			<section class="panel">
				<header class="panel-heading">
					<h2 class="panel-title">Are you sure?</h2>
				</header>
				<div class="panel-body">
					<div class="modal-wrapper">
						<div class="modal-icon">
							<i class="fa fa-question-circle"></i>
						</div>
						<div class="modal-text">
							<h4>Primary</h4>
							<p>Are you sure that you want to delete this image?</p>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<div class="row">
						<div class="col-md-12 text-right">
							<button class="btn btn-primary modal-confirm">Confirm</button>
							<button class="btn btn-default modal-dismiss">Cancel</button>
						</div>
					</div>
				</footer>
			</section>
		</div>
		
		
		

		<!-- Vendor -->
		<script src="<?php echo  base_url(); ?>assets/front/vendor/jquery/jquery.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/jquery.appear/jquery.appear.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/jquery.easing/jquery.easing.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/jquery-cookie/jquery-cookie.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/bootstrap/bootstrap.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/common/common.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/jquery.validation/jquery.validation.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/jquery.stellar/jquery.stellar.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/jquery.easy-pie-chart/jquery.easy-pie-chart.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/jquery.gmap/jquery.gmap.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/isotope/jquery.isotope.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/owlcarousel/owl.carousel.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/jflickrfeed/jflickrfeed.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/magnific-popup/jquery.magnific-popup.js"></script>
		<script src="<?php echo  base_url(); ?>assets/front/vendor/vide/vide.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="<?php echo  base_url(); ?>assets/front/js/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="<?php echo  base_url(); ?>assets/front/js/custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="<?php echo  base_url(); ?>assets/front/js/theme.init.js"></script>


	
<script>
 var fetch = angular.module('myapp', []);

 fetch.controller('inventoryCtrl', ['$scope', '$http', function ($scope, $http) {

   $scope.getinvens = function(){
    $http({
     method: 'get',
     url: '<?php echo base_url(); ?>index.php/Home/get_list'
    }).then(function successCallback(response) {
      console.log(response.data);
	  //alert(response.data);
      $scope.invens = response.data;	  
    }); 
   }
   $scope.getinvens();
 }]);
 
 
 $scope.invdetails=function(user){
	$('#modalHeaderColorPrimary').modal('show');
 $scope.getinvens=user;
}

 </script>

	</body>
</html>
