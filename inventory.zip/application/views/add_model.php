
<header class="page-header">
	<h2><?php echo $page;?></h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="<?php echo  base_url(); ?>index.php/Admin/index">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span><a href="<?php echo  base_url(); ?>index.php/admin/model">Model</a></span></li>
			<li><span><?php echo $page;?></span></li>
		</ol>

		<a class="sidebar-right-toggle" data-open=""><i class="fa fa-chevron-left"></i></a>
	</div>
</header>

<!-- start: page -->
<div class="row">
<div class="col-md-12">
	<form id="form" action="<?php echo base_url();?>index.php/admin/add_model" method="post" class="form-horizontal" enctype="multipart/form-data">
		<section class="panel">
			<header class="panel-heading">
				<div class="panel-actions">
					<a href="#" class="fa fa-caret-down"></a>
					<a href="#" class="fa fa-times"></a>
				</div>
				<h2 class="panel-title">Model Form</h2>				
			</header>
			<div class="panel-body">
			<div class="row">
			<div class="col-sm-12 col-md-6">
				<div class="form-group">
					<label class="col-sm-4 control-label">Manufacture<span class="required">*</span></label>
					<div class="col-sm-8">
					<?php //echo print_r($manufacture_data);?>
						<select data-plugin-selectTwo class="form-control populate" name="manufacture_name" required>
							<option value="">Select Manufacture</option>
							<?php foreach($manufacture_data as $mdata){?>
							<option value="<?php echo $mdata['id'];?>"><?php echo $mdata['attr_name'];?></option>
							<?php } ?>
						</select>
					</div>
				</div>
			</div>
			<div class="col-sm-12 col-md-6">				
				<div class="form-group">
					<label class="col-sm-4 control-label">Model Name <span class="required">*</span></label>
					<div class="col-sm-8">
					<input type="text" class="form-control" name="model_name" value="" id="inputDefault" required>
					</div>
				</div>
			</div>
			</div>
			<br>
			<div class="row">
			<div class="col-sm-12 col-md-6">
				<div class="form-group">
					<label class="col-md-4 control-label">Color Set</label>
					<div class="col-md-8">
						<input type="text" data-plugin-colorpicker="" class="colorpicker-default form-control colorpicker-element" name="colorset" value="#8fff00">
					</div>
				</div>
			</div>
			<div class="col-sm-12 col-md-6">
			<div class="form-group">
				<label class="col-md-4 control-label"> Manufacturing Year</label>
				<div class="col-md-8">
					<div class="input-group">
						<span class="input-group-addon">
							<i class="fa fa-calendar"></i>
						</span>
						<input type="text" data-plugin-datepicker="" id="datepicker" class="form-control" name="Manufacturing_year">
					</div>
				</div>
			</div>
			</div>
			</div><br>
			
			
			<div class="row">
			<div class="col-sm-12 col-md-6">
				<div class="form-group">
					<label class="col-md-4 control-label">Registration Number</label>
					<div class="col-md-8">
					<input type="text"  class="form-control populate" value="" name="registration_number" >
					</div>
				</div>
			</div>
			<div class="col-sm-12 col-md-6">
			<div class="form-group">
				<label class="col-md-4 control-label" for="textareaDefault">Note</label>
				<div class="col-md-8">
					<textarea class="form-control" rows="2" data-plugin-maxlength maxlength="140" name="noteinventory"></textarea>
					
				</div>
			</div>
			</div>
			</div><br>
			
			
			<div class="row">
			<div class="col-sm-12 col-md-6">			
				<div class="form-group">
					<label class="col-md-4 control-label">Image Upload</label>
					<div class="col-md-8">
						<div class="fileupload fileupload-new" data-provides="fileupload">
						<div id="uploaded_image" style="display:none;">
						<img src="<?php echo  base_url(); ?>assets/images/loading.gif" style="width: 52px;">
						</div>
							<div class="input-append">
								<div class="uneditable-input">
									<i class="fa fa-file fileupload-exists"></i>
									<span class="fileupload-preview"></span>
								</div>
								<span class="btn btn-default btn-file">
									<span class="fileupload-exists">Change</span>
									<span class="fileupload-new">Select file</span>
									<input type="file" name="file1" id="uploadf" />
								</span>
								<a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
								<input type="hidden" name="fst_image" id="fst_image" value="" />								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-12 col-md-6">			
				<div class="form-group">
					<label class="col-md-4 control-label">Image Upload</label>
					<div class="col-md-8">
						<div class="fileupload fileupload-new" data-provides="fileupload">
						<div id="uploaded_image2" style="display:none;">
						<img src="<?php echo  base_url(); ?>assets/images/loading.gif" style="width: 52px;">
						</div>
							<div class="input-append">
								<div class="uneditable-input">
									<i class="fa fa-file fileupload-exists"></i>
									<span class="fileupload-preview"></span>
								</div>
								<span class="btn btn-default btn-file">
									<span class="fileupload-exists">Change</span>
									<span class="fileupload-new">Select file</span>
									<input type="file" name="file2" id="file2" />
								</span>
								<a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
								<input type="hidden" name="sec_image" id="sec_image" value="" />	
							</div>
						</div>
					</div>
				</div>
			</div>
			</div>


			</div>
			<footer class="panel-footer">
				<div class="row">
					<div class="col-sm-9 col-sm-offset-3">
						<input type="hidden" name="save" value="save"/>
						<button class="btn btn-primary">Submit</button>
						<button type="reset" class="btn btn-default">Reset</button>
					</div>
				</div>
			</footer>
		</section>
	</form>
</div>
</div>
