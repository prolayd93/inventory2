<header class="page-header">
	<h2><?php echo $page;?></h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="<?php echo  base_url(); ?>">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span><?php echo $page;?></span></li>
		</ol>

		<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
			<a href="#" class="fa fa-times"></a>
		</div>

		<h2 class="panel-title"><?php echo $page;?></h2>
	</header>
	<div class="panel-body">
	<div class="row">
		<div class="col-sm-6">
			<div class="mb-md">
				<a href="<?php echo  base_url(); ?>index.php/admin/add_model" class="btn btn-primary">Add <i class="fa fa-plus"></i></a>
			</div>
		</div>
	</div>

		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th>Manufacture Name</th>
					<th>Model Name</th>
					
					
				</tr>
			</thead>
			<tbody>
			<?php 
			//echo "<pre>", print_r($mrecord), "</pre>";
			if(!empty($model_query)){
			foreach($model_query as $mod) {?>			
				<tr class="gradeX">
					<td><?php echo $mod['manufacture_id'];?></td>
					<td><?php echo $mod['model_name'];?>
					</td>
					
					
				</tr>
			<?php }
			}
			?>
				
			</tbody>
		</table>
	</div>
</section>
