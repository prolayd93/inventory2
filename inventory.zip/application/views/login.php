
<section class="body-sign">
	<div class="center-sign">				
		<h1 class="logo pull-left">Car Inventory</h1>
		<div class="panel panel-sign">
			<div class="panel-title-sign mt-xl text-right">
				<h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i><?php echo date('d M Y'); ?></h2>
				<h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i> Sign In</h2>
			</div>

			<div class="panel-body">
				<?php if(!empty($error)){?>
				<div class="alert alert-danger">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong>Invalid!</strong> entered useremail and password does not exist!!
				</div>
				<?php }?>
				<form action="<?php echo base_url();?>index.php/login/admin_login" method="post" >
					<div class="form-group mb-lg">
						<label>Useremail</label>
						<div class="input-group input-group-icon">
							<input name="admin_email" type="text" class="form-control input-lg" value="admin@admin.com" />
							<span class="input-group-addon">
								<span class="icon icon-lg">
									<i class="fa fa-user"></i>
								</span>
							</span>
						</div>
					</div>

					<div class="form-group mb-lg">
						<div class="clearfix">
							<label class="pull-left">Password</label>
							<!-- <a href="#" class="pull-right">Lost Password?</a> -->
						</div>
						<div class="input-group input-group-icon">
							<input name="admin_pass" type="password" class="form-control input-lg" value="123456" />
							<span class="input-group-addon">
								<span class="icon icon-lg">
									<i class="fa fa-lock"></i>
								</span>
							</span>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-8">
							<div class="checkbox-custom checkbox-default">
								<input id="RememberMe" name="rememberme" type="checkbox"/>
								<label for="RememberMe">Remember Me</label>
							</div>
						</div>
						<div class="col-sm-4 text-right">
							<button type="submit" class="btn btn-primary hidden-xs">Sign In</button>
							<button type="submit" class="btn btn-primary btn-block btn-lg visible-xs mt-lg">Sign In</button>
						</div>
					</div>

					<!-- <span class="mt-lg mb-lg line-thru text-center text-uppercase">
						<span>or</span>
					</span> -->

					
				</form>
			</div>
		</div>
		<p class="text-center text-muted mt-md mb-md">&copy; Copyright <?php echo date('Y');?>. All Rights Reserved. | <a href="<?php echo  base_url(); ?>">Home</a></p>
	</div>
</section>
		