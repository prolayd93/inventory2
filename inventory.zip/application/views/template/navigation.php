<div class="container">
	<?php if(!empty($this->session->userdata("client_id"))){?>
	<nav class="nav-main mega-menu">
		<ul class="nav nav-pills nav-main" id="mainMenu">
			<li class="active">
				<a class="dropdown-toggle" href="<?php echo base_url(); ?>">
					Dashboard					
				</a>				
			</li>
			<li class="dropdown">
				<a class="dropdown-toggle" href="#">
					Manufacture
					<i class="fa fa-angle-down"></i>
				</a>
				<ul class="dropdown-menu">
					<li><a href="<?php echo  base_url(); ?>index.php/admin/manufacture">Manufacture</a></li>
					<li><a href="<?php echo  base_url(); ?>index.php/admin/model">Model</a></li>
				</ul>
			</li>
			<li>
				<a href="<?php echo  base_url(); ?>index.php/admin/inventory">View Inventory</a>
			</li>			
			<li class="dropdown mega-menu-item mega-menu-signin signin logged" id="headerAccount">
				<a class="dropdown-toggle" href="#">
					<i class="fa fa-user"></i> <?php if(!empty($this->session->userdata("role"))){echo $this->session->userdata("role");}?>
					<i class="fa fa-angle-down"></i>
				</a>
				<ul class="dropdown-menu">
					<li>
						<div class="mega-menu-content">
							<div class="row">
								<div class="col-md-8">
									<div class="user-avatar">
										<div class="img-thumbnail">
											<img src="<?php echo  base_url(); ?>assets/img/clients/client-1.jpg" alt="">
										</div>
										<p><strong>
											<?php if(!empty($this->session->userdata("display_name"))){echo $this->session->userdata("display_name");}?>
										</strong><span><?php if(!empty($this->session->userdata("designations"))){echo $this->session->userdata("designations");}?></span></p>
									</div>
								</div>
								<div class="col-md-4">
									<ul class="list-account-options">
										<li>
											<a href="#">My Account</a>
										</li>
										<li>
											<a href="<?php echo  base_url();?>index.php/login/logout">Log Out</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</li>
				</ul>
			</li>
		


		</ul>
	</nav>
	<?php }else{?>

<nav class="nav-main mega-menu">
		<ul class="nav nav-pills nav-main" id="mainMenu">
			<li >
				<a class="dropdown-toggle" href="<?php echo base_url(); ?>">
					Login					
				</a>				
			</li>
</ul>
</nav>

<?php }
	?>
</div>