</section>
			</div>

			
		</section>


		<!-- Vendor -->
		<script src="<?php echo  base_url(); ?>assets/vendor/jquery/jquery.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap/js/bootstrap.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/nanoscroller/nanoscroller.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/magnific-popup/magnific-popup.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
		
		<!-- Specific Page Vendor -->		
		<script src="<?php echo  base_url(); ?>assets/vendor/select2/select2.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
		
		<!-- Specific Page Vendor -->
		<script src="<?php echo  base_url(); ?>assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/select2/select2.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/jquery-maskedinput/jquery.maskedinput.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/fuelux/js/spinner.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/dropzone/dropzone.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-markdown/js/markdown.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-markdown/js/to-markdown.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-markdown/js/bootstrap-markdown.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/codemirror/lib/codemirror.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/codemirror/addon/selection/active-line.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/codemirror/addon/edit/matchbrackets.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/codemirror/mode/javascript/javascript.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/codemirror/mode/xml/xml.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/codemirror/mode/htmlmixed/htmlmixed.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/codemirror/mode/css/css.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/summernote/summernote.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-maxlength/bootstrap-maxlength.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/ios7-switch/ios7-switch.js"></script>
		
		<script src="<?php echo  base_url(); ?>assets/vendor/jquery-autosize/jquery.autosize.js"></script>
		<script src="<?php echo  base_url(); ?>assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

		
		<!-- Theme Base, Components and Settings -->
		<script src="<?php echo  base_url(); ?>assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="<?php echo  base_url(); ?>assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="<?php echo  base_url(); ?>assets/javascripts/theme.init.js"></script>


		<!-- Examples -->
		<script src="<?php echo  base_url(); ?>assets/javascripts/dashboard/examples.dashboard.js"></script>
		<script src="<?php echo  base_url(); ?>assets/javascripts/tables/examples.datatables.editable.js"></script>
		<script src="<?php echo  base_url(); ?>assets/javascripts/forms/examples.advanced.form.js" /></script>
		
		
		<script>
		
		$("#datepicker").datepicker({
    format: "yyyy",
    viewMode: "years", 
    minViewMode: "years"
});


		$(document).ready(function(){
			$(document).on('change', '#uploadf', function(){
				var name = document.getElementById("uploadf").files[0].name;
				var form_data = new FormData();
				var ext = name.split('.').pop().toLowerCase();
				if(jQuery.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
				{
					alert("Invalid Image File");
				}
				var oFReader = new FileReader();
				oFReader.readAsDataURL(document.getElementById("uploadf").files[0]);
				var f = document.getElementById("uploadf").files[0];
				var fsize = f.size||f.fileSize;
				if(fsize > 2000000){
					alert("Image File Size is very big");
					}else{
						form_data.append("file1", document.getElementById('uploadf').files[0]);						
						$.ajax({
						url:"<?php echo  base_url(); ?>index.php/admin/upload_files",
						method:"POST",
						data: form_data,
						contentType: false,
						cache: false,
						processData: false,
						beforeSend:function(){//loading.gif
						 $('#uploaded_image').show();
						},   
						success:function(data)
						{
							setTimeout(function(){
								$('#uploaded_image').hide();
									$('#fst_image').val(data);
							}, 1000);
							 
						 
						}
					   });
					}
			});
		});
		
		
		
		
		$(document).ready(function(){
			$(document).on('change', '#file2', function(){
				var name = document.getElementById("file2").files[0].name;
				var form_data = new FormData();
				var ext = name.split('.').pop().toLowerCase();
				if(jQuery.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
				{
					alert("Invalid Image File");
				}
				var oFReader = new FileReader();
				oFReader.readAsDataURL(document.getElementById("file2").files[0]);
				var f = document.getElementById("file2").files[0];
				var fsize = f.size||f.fileSize;
				if(fsize > 2000000){
					alert("Image File Size is very big");
					}else{
						form_data.append("file1", document.getElementById('file2').files[0]);						
						$.ajax({
						url:"<?php echo  base_url(); ?>index.php/admin/upload_files",
						method:"POST",
						data: form_data,
						contentType: false,
						cache: false,
						processData: false,
						beforeSend:function(){
						 $('#uploaded_image2').show();
						},   
						success:function(data)
						{
							setTimeout(function(){
								$('#uploaded_image2').hide();
									$('#sec_image').val(data);
							}, 1000);
						 
						}
					   });
					}
			});
		});
</script>

	</body>
</html>