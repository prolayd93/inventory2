<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Inventory_Model extends CI_Model {
    
    protected $table_name;
    
    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->table_name = 'model_tbl';
    }
    
    public function getAll() {
        return $this->db->from($this->table_name)->get()->result_array();
		return $this->db->last_query();
    }
	
	

	function getRecords(){
		$content=$this->db->select('c.*,a.attr_name,a.id')
			->from('model_tbl c')
			->join('manufacture a','c.manufacture_id = a.id', 'left')
			->where('c.client_id',$this->session->userdata('client_id'))							
			->where('c.status',1)
			 ->get();
	//return $this->db->last_query();
	return $content->result_array();	

  }





 
}