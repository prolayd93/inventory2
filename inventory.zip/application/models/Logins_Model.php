<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class logins_model extends CI_Model
{
   
	public function __construct()
	{
		parent::__construct();  
        $this->load->database();
		 
		 
	}
   			
	public function admin_login(){
		$email=$this->input->post('admin_email');
		$password=$this->input->post('admin_pass');
		$salt=$this->config->item('database_key');
		$admin=$this->db->query("SELECT * FROM master_admin WHERE email='".$email."' and password=AES_ENCRYPT('".$password."', '".$salt."')");
		//return $this->db->last_query();
		//exit;
			if($admin->num_rows()>0){							
				$sess_array=array(
				 "client_id" => $admin->row('id'), 
				 "email" => $admin->row('email'),
				 "username"=>$admin->row("username"),
				 "display_name"=>$admin->row("display_name"),
				 "designations"=>$admin->row("designations"),
				 "role"=>'Client admin',
				 );
				$this->session->set_userdata($sess_array); 
				return 'success';
			}						
			else
			{
				return 'fail';					
			}
						
	}
				
	function logout()
	{
		$this->session->sess_destroy();
	}
				
//function to set userdata
          public function setUserdata($id)
		  {
			  $admin=$this->db->query("select * from client_admin where clinet_id=".$id."");
			  
			  $sess_array=array(
							             "client_id" => $admin->row('clinet_id'), 
							             "email" => $admin->row('contact_email'),
										 "profile_pic" => $admin->row('profile_pic'),
										 "user_id"  => '',
										 "Region" =>'',
										 "manager_id" => '',
										 "role"=>'Client admin',
										 );
							$this->session->set_userdata($sess_array); 
		  }
}
?>