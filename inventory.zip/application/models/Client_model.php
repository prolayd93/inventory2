<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Client_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();  
        $this->load->database();		
		date_default_timezone_set('Asia/Calcutta');
	}
	public function get_record_manufacture(){
		$get_orderdata=$this->db->select('*')
			->from('manufacture')
			 ->where('client_id',$this->session->userdata('client_id')) 
			  ->where('status','1') 
			->get();
		//return $this->db->last_query(); 
		return $get_orderdata->result_array();
	}
	public function get_manufacture_data($tablename=false,$type=false, $wherecondition_key,$wherecondition_value=false){
		switch($type){
			case "select":
			$this->db->select('*')->from($tablename);
			if(!empty($wherecondition_key))
				{
					$this->db->where($wherecondition_key,$wherecondition_value);
				}
				$this->db->where('client_id',$this->session->userdata('client_id'));
				$table_qry=$this->db->get();
				//echo $this->db->last_query();
			    return $table_qry->result_array();
			break;
			default:
			  return "No type of selection made to perform action";
		}
	}
	
	public function add_manufacture_record(){
		
		$array=array(
		'attr_name' => $this->input->post('manufacture_name'),
		'client_id'=>$this->session->userdata('client_id'),
		'created'=>date('Y-m-d H:i:s'));
		$this->db->insert('manufacture',$array);
		$last_id=$this->db->insert_id();
		return 'success';
	}
	public function add_model_record(){		
		$array=array(
		'manufacture_id' => $this->input->post('manufacture_name'),
		'model_name' => $this->input->post('model_name'),
		'color' => $this->input->post('colorset'),
		'manufacturing_year' => $this->input->post('Manufacturing_year'),
		'registration_number' => $this->input->post('registration_number'),
		'noteinventory'=>$this->input->post('noteinventory'),
		'file_one'=>$this->input->post('fst_image'),
		'file_two'=>$this->input->post('sec_image'),
		'client_id'=>$this->session->userdata('client_id'),		
		'created'=>date('Y-m-d H:i:s'));
		$this->db->insert('model_tbl',$array);
		$last_id=$this->db->insert_id();
		return 'success';
	}
	
	public function upload_files(){
		//print_r($_FILES);
		$imagearray=array();
		$data=array();
		$path='./assets/products/';
		
		if(($_FILES['file1']['size'] != 0) && $_FILES['file1']['error'] == 0)
		{
			//echo $_FILES['file1']['name'];
			$product_image=$_FILES["file1"]["name"];				
				if($_FILES["file1"]["name"]){
				$newfilename = rand(1,99999).time().'_'.$_FILES["file1"]["name"]; 
				
				if(move_uploaded_file($_FILES["file1"]["tmp_name"],$path.$newfilename))
				{						
					array_push($imagearray,$newfilename);
				
				$array=array(
				'file_name' => $newfilename,
				'file_size' => $_FILES['file1']['size'],
				'file_type' => $_FILES['file1']['type'],
				'file_temp' => $_FILES["file1"]["tmp_name"],		
				'client_id'=>$this->session->userdata('client_id'),
				);				
				$this->db->insert('upload_file',$array);
				$last_id=$this->db->insert_id();
				
				}
			}
			
			return $newfilename;
		}
	}
}